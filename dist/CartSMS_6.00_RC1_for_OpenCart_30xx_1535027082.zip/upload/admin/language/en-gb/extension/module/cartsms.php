<?php

$_['heading_title']       = ' 💬 <b style="color: #00c0f3;">Cart</b><b>SMS</b> - SMS module for OpenCart 🌍';
