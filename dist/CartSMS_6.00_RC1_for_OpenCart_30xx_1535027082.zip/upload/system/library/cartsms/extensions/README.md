Simple PHP framework for BulkGate extensions
